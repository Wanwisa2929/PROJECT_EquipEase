import React, { useEffect, useState } from "react";
import "./Admin.css";
 
const LS_KEYS = {
  BORROWING: "eq_borrowing",
  HISTORY: "eq_history",
};
 
function readLS(key, fallback) {
  try {
    return JSON.parse(localStorage.getItem(key)) ?? fallback;
  } catch {
    return fallback;
  }
}
 
const Admin = () => {
  const [borrowing, setBorrowing] = useState([]);
  const [returned, setReturned] = useState([]);
 
  useEffect(() => {
    const b = readLS(LS_KEYS.BORROWING, []);
    const h = readLS(LS_KEYS.HISTORY, []);
    setBorrowing(b);
    setReturned(h.filter((r) => r.status === "Returned"));
  }, []);
 
  return (
    <main className="content">
      <h1>Admin</h1>
 
      {/* Borrow List */}
      <h2>Borrow List</h2>
      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Number</th>
              <th>ID</th>
              <th>Name</th>
              <th>Item</th>
              <th>Borrow Date</th>
              <th>Borrow Time</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {borrowing.length === 0 ? (
              <tr>
                <td colSpan="7" className="no-data">
                  No current borrowing.
                </td>
              </tr>
            ) : (
              borrowing.map((b, i) => (
                <tr key={i}>
                  <td>{String(i + 1).padStart(3, "0")}</td>
                  <td>{b.studentId || "-"}</td>
                  <td>{b.studentName || "-"}</td>
                  <td>{b.item}</td>
                  <td>{b.borrowDate}</td>
                  <td>{b.borrowTime}</td>
                  <td>{b.status}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
 
      {/* Return List */}
      <h2 style={{ marginTop: "32px" }}>Return List</h2>
      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Number</th>
              <th>ID</th>
              <th>Name</th>
              <th>Item</th>
              <th>Return Date</th>
              <th>Return Time</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {returned.length === 0 ? (
              <tr>
                <td colSpan="7" className="no-data">
                  No returned items.
                </td>
              </tr>
            ) : (
              returned.map((r, i) => (
                <tr key={i}>
                  <td>{String(i + 1).padStart(3, "0")}</td>
                  <td>{r.studentId || "-"}</td>
                  <td>{r.studentName || "-"}</td>
                  <td>{r.item}</td>
                  <td>{r.returnDate}</td>
                  <td>{r.returnTime || "-"}</td>
                  <td>{r.status}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </main>
  );
};
 
export default Admin;
 